// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'home_item.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_HomeItem _$$_HomeItemFromJson(Map<String, dynamic> json) => _$_HomeItem(
      id: json['id'] as String,
      imagePath: json['imagePath'] as String,
      title: json['title'] as String,
      location: json['location'] as String,
      time: json['time'] as String,
      desc: json['desc'] as String,
      price: json['price'] as String,
      likes: json['likes'] as int,
      like: json['like'] as bool,
      category: json['category'] as String,
      item_status: json['item_status'] as int,
      user_id: json['user_id'] as String,
    );

Map<String, dynamic> _$$_HomeItemToJson(_$_HomeItem instance) =>
    <String, dynamic>{
      'id': instance.id,
      'imagePath': instance.imagePath,
      'title': instance.title,
      'location': instance.location,
      'time': instance.time,
      'desc': instance.desc,
      'price': instance.price,
      'likes': instance.likes,
      'like': instance.like,
      'category': instance.category,
      'item_status': instance.item_status,
      'user_id': instance.user_id,
    };
