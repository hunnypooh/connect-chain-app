// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'home_item.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

HomeItem _$HomeItemFromJson(Map<String, dynamic> json) {
  return _HomeItem.fromJson(json);
}

/// @nodoc
mixin _$HomeItem {
  String get id =>
      throw _privateConstructorUsedError; //TODO goods_id 로 변수 이름 변경
  String get imagePath =>
      throw _privateConstructorUsedError; //TODO List 타입의 image
  String get title => throw _privateConstructorUsedError;
  String get location => throw _privateConstructorUsedError; //TODO 삭제예정
  String get time => throw _privateConstructorUsedError;
  String get desc => throw _privateConstructorUsedError; //설명
  String get price => throw _privateConstructorUsedError;
  int get likes => throw _privateConstructorUsedError;
  bool get like => throw _privateConstructorUsedError; //관심 여부
  String get category => throw _privateConstructorUsedError;
  int get item_status => throw _privateConstructorUsedError; //판매중, 거래완료
  String get user_id => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $HomeItemCopyWith<HomeItem> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $HomeItemCopyWith<$Res> {
  factory $HomeItemCopyWith(HomeItem value, $Res Function(HomeItem) then) =
      _$HomeItemCopyWithImpl<$Res>;
  $Res call(
      {String id,
      String imagePath,
      String title,
      String location,
      String time,
      String desc,
      String price,
      int likes,
      bool like,
      String category,
      int item_status,
      String user_id});
}

/// @nodoc
class _$HomeItemCopyWithImpl<$Res> implements $HomeItemCopyWith<$Res> {
  _$HomeItemCopyWithImpl(this._value, this._then);

  final HomeItem _value;
  // ignore: unused_field
  final $Res Function(HomeItem) _then;

  @override
  $Res call({
    Object? id = freezed,
    Object? imagePath = freezed,
    Object? title = freezed,
    Object? location = freezed,
    Object? time = freezed,
    Object? desc = freezed,
    Object? price = freezed,
    Object? likes = freezed,
    Object? like = freezed,
    Object? category = freezed,
    Object? item_status = freezed,
    Object? user_id = freezed,
  }) {
    return _then(_value.copyWith(
      id: id == freezed
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      imagePath: imagePath == freezed
          ? _value.imagePath
          : imagePath // ignore: cast_nullable_to_non_nullable
              as String,
      title: title == freezed
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String,
      location: location == freezed
          ? _value.location
          : location // ignore: cast_nullable_to_non_nullable
              as String,
      time: time == freezed
          ? _value.time
          : time // ignore: cast_nullable_to_non_nullable
              as String,
      desc: desc == freezed
          ? _value.desc
          : desc // ignore: cast_nullable_to_non_nullable
              as String,
      price: price == freezed
          ? _value.price
          : price // ignore: cast_nullable_to_non_nullable
              as String,
      likes: likes == freezed
          ? _value.likes
          : likes // ignore: cast_nullable_to_non_nullable
              as int,
      like: like == freezed
          ? _value.like
          : like // ignore: cast_nullable_to_non_nullable
              as bool,
      category: category == freezed
          ? _value.category
          : category // ignore: cast_nullable_to_non_nullable
              as String,
      item_status: item_status == freezed
          ? _value.item_status
          : item_status // ignore: cast_nullable_to_non_nullable
              as int,
      user_id: user_id == freezed
          ? _value.user_id
          : user_id // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
abstract class _$$_HomeItemCopyWith<$Res> implements $HomeItemCopyWith<$Res> {
  factory _$$_HomeItemCopyWith(
          _$_HomeItem value, $Res Function(_$_HomeItem) then) =
      __$$_HomeItemCopyWithImpl<$Res>;
  @override
  $Res call(
      {String id,
      String imagePath,
      String title,
      String location,
      String time,
      String desc,
      String price,
      int likes,
      bool like,
      String category,
      int item_status,
      String user_id});
}

/// @nodoc
class __$$_HomeItemCopyWithImpl<$Res> extends _$HomeItemCopyWithImpl<$Res>
    implements _$$_HomeItemCopyWith<$Res> {
  __$$_HomeItemCopyWithImpl(
      _$_HomeItem _value, $Res Function(_$_HomeItem) _then)
      : super(_value, (v) => _then(v as _$_HomeItem));

  @override
  _$_HomeItem get _value => super._value as _$_HomeItem;

  @override
  $Res call({
    Object? id = freezed,
    Object? imagePath = freezed,
    Object? title = freezed,
    Object? location = freezed,
    Object? time = freezed,
    Object? desc = freezed,
    Object? price = freezed,
    Object? likes = freezed,
    Object? like = freezed,
    Object? category = freezed,
    Object? item_status = freezed,
    Object? user_id = freezed,
  }) {
    return _then(_$_HomeItem(
      id: id == freezed
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      imagePath: imagePath == freezed
          ? _value.imagePath
          : imagePath // ignore: cast_nullable_to_non_nullable
              as String,
      title: title == freezed
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String,
      location: location == freezed
          ? _value.location
          : location // ignore: cast_nullable_to_non_nullable
              as String,
      time: time == freezed
          ? _value.time
          : time // ignore: cast_nullable_to_non_nullable
              as String,
      desc: desc == freezed
          ? _value.desc
          : desc // ignore: cast_nullable_to_non_nullable
              as String,
      price: price == freezed
          ? _value.price
          : price // ignore: cast_nullable_to_non_nullable
              as String,
      likes: likes == freezed
          ? _value.likes
          : likes // ignore: cast_nullable_to_non_nullable
              as int,
      like: like == freezed
          ? _value.like
          : like // ignore: cast_nullable_to_non_nullable
              as bool,
      category: category == freezed
          ? _value.category
          : category // ignore: cast_nullable_to_non_nullable
              as String,
      item_status: item_status == freezed
          ? _value.item_status
          : item_status // ignore: cast_nullable_to_non_nullable
              as int,
      user_id: user_id == freezed
          ? _value.user_id
          : user_id // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_HomeItem implements _HomeItem {
  _$_HomeItem(
      {required this.id,
      required this.imagePath,
      required this.title,
      required this.location,
      required this.time,
      required this.desc,
      required this.price,
      required this.likes,
      required this.like,
      required this.category,
      required this.item_status,
      required this.user_id});

  factory _$_HomeItem.fromJson(Map<String, dynamic> json) =>
      _$$_HomeItemFromJson(json);

  @override
  final String id;
//TODO goods_id 로 변수 이름 변경
  @override
  final String imagePath;
//TODO List 타입의 image
  @override
  final String title;
  @override
  final String location;
//TODO 삭제예정
  @override
  final String time;
  @override
  final String desc;
//설명
  @override
  final String price;
  @override
  final int likes;
  @override
  final bool like;
//관심 여부
  @override
  final String category;
  @override
  final int item_status;
//판매중, 거래완료
  @override
  final String user_id;

  @override
  String toString() {
    return 'HomeItem(id: $id, imagePath: $imagePath, title: $title, location: $location, time: $time, desc: $desc, price: $price, likes: $likes, like: $like, category: $category, item_status: $item_status, user_id: $user_id)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_HomeItem &&
            const DeepCollectionEquality().equals(other.id, id) &&
            const DeepCollectionEquality().equals(other.imagePath, imagePath) &&
            const DeepCollectionEquality().equals(other.title, title) &&
            const DeepCollectionEquality().equals(other.location, location) &&
            const DeepCollectionEquality().equals(other.time, time) &&
            const DeepCollectionEquality().equals(other.desc, desc) &&
            const DeepCollectionEquality().equals(other.price, price) &&
            const DeepCollectionEquality().equals(other.likes, likes) &&
            const DeepCollectionEquality().equals(other.like, like) &&
            const DeepCollectionEquality().equals(other.category, category) &&
            const DeepCollectionEquality()
                .equals(other.item_status, item_status) &&
            const DeepCollectionEquality().equals(other.user_id, user_id));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(id),
      const DeepCollectionEquality().hash(imagePath),
      const DeepCollectionEquality().hash(title),
      const DeepCollectionEquality().hash(location),
      const DeepCollectionEquality().hash(time),
      const DeepCollectionEquality().hash(desc),
      const DeepCollectionEquality().hash(price),
      const DeepCollectionEquality().hash(likes),
      const DeepCollectionEquality().hash(like),
      const DeepCollectionEquality().hash(category),
      const DeepCollectionEquality().hash(item_status),
      const DeepCollectionEquality().hash(user_id));

  @JsonKey(ignore: true)
  @override
  _$$_HomeItemCopyWith<_$_HomeItem> get copyWith =>
      __$$_HomeItemCopyWithImpl<_$_HomeItem>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_HomeItemToJson(
      this,
    );
  }
}

abstract class _HomeItem implements HomeItem {
  factory _HomeItem(
      {required final String id,
      required final String imagePath,
      required final String title,
      required final String location,
      required final String time,
      required final String desc,
      required final String price,
      required final int likes,
      required final bool like,
      required final String category,
      required final int item_status,
      required final String user_id}) = _$_HomeItem;

  factory _HomeItem.fromJson(Map<String, dynamic> json) = _$_HomeItem.fromJson;

  @override
  String get id;
  @override //TODO goods_id 로 변수 이름 변경
  String get imagePath;
  @override //TODO List 타입의 image
  String get title;
  @override
  String get location;
  @override //TODO 삭제예정
  String get time;
  @override
  String get desc;
  @override //설명
  String get price;
  @override
  int get likes;
  @override
  bool get like;
  @override //관심 여부
  String get category;
  @override
  int get item_status;
  @override //판매중, 거래완료
  String get user_id;
  @override
  @JsonKey(ignore: true)
  _$$_HomeItemCopyWith<_$_HomeItem> get copyWith =>
      throw _privateConstructorUsedError;
}
