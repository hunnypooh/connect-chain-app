import 'package:flutter/material.dart';

class HistoryScreen extends StatelessWidget {
  static const routename = '/history-list';

  final infos = [
    PageInfo('assets/images/macbook.jpg', '1번째 판매자', '거래쿨', '거래일시 : 19.8.3'),
    PageInfo('assets/images/macbook2.jpg', '2번째 판매자', '쿨쿨', '거래일시 : 20.3.6'),
    PageInfo('assets/images/macbook.jpg', '3번째 판매자', '콜콜', '거래일시 : 22.1.3'),
  ];

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('거래 기록'),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: ListView(
        itemExtent: 120,
        children: infos.map((info) => makeRowItem(context, info)).toList(),
      ),
    );
  }

  Widget makeRowItem(BuildContext context, PageInfo info) {
    return Center(
      child: Container(
        color: Colors.white,
        child: ListTile(
          leading: Image.asset(
            info.image,
            width: 100,
            height: 100,
            fit: BoxFit.cover,
          ),
          title: Row(
            children: <Widget>[
              Expanded(
                child: Text(
                  info.num,
                  style: TextStyle(fontSize: 19, color: Colors.blueGrey),
                ),
              ),
              Container(
                child: Text(
                  info.when,
                  style: TextStyle(
                      fontWeight: FontWeight.bold, color: Colors.black),
                ),
                padding: EdgeInsets.only(left: 12.0, right: 12.0),
              )
            ],
          ),
          onTap: () {
            Navigator.push(
                context,
                MaterialPageRoute<void>(
                    builder: (BuildContext context) => Detail(info: info)));
          },
        ),
      ),
    );
  }
}

class PageInfo {
  PageInfo(this.image, this.num, this.who, this.when);

  String image;
  String num;
  String who;
  String when;
}

class Detail extends StatelessWidget {
  Detail({Key? key, required this.info}) : super(key: key);
  final PageInfo info;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(info.when)),
      body: SingleChildScrollView(
        child: Column(children: <Widget>[
          Container(
            child: Center(
              child: Text(
                info.who,
                style: TextStyle(fontSize: 21.0, color: Colors.black),
              ),
            ),
            padding: EdgeInsets.all(20.0),
          ),
          Container(
            child: Image.asset(
              info.image,
              fit: BoxFit.contain,
            ),
            padding: EdgeInsets.all(10.0),
          ),
        ]),
      ),
    );
  }
}
