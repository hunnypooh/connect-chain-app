import 'package:demo_app/screens/history_screen.dart';
import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';

class ProductDetailScreen extends StatefulWidget {
  static const routeName = '/product-detail';
  const ProductDetailScreen({Key? key}) : super(key: key);

  @override
  ProductDetailScreenState createState() => ProductDetailScreenState();
}

class ProductDetailScreenState extends State<ProductDetailScreen> {
  int _current = 0;
  List<String> imgList = [
    "assets/images/macbook.jpg",
    "assets/images/macbook2.jpg",
  ];
  bool putincart = false;
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  PreferredSizeWidget _appbarWidget() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      leading: IconButton(
          onPressed: () => Navigator.of(context).pop(),
          icon: Icon(
            Icons.arrow_back,
            color: Colors.white,
          )),
      actions: [
        IconButton(
            onPressed: () {},
            icon: Icon(
              Icons.more_vert,
              color: Colors.white,
            ))
      ],
    );
  }

  Widget sliderWidget() {
    return Container(
        child: Stack(
      children: [
        CarouselSlider(
          options: CarouselOptions(
            height: MediaQuery.of(context).size.width,
            initialPage: 0,
            enableInfiniteScroll: false,
            viewportFraction: 1.0,
            enlargeCenterPage: false,
            onPageChanged: (index, reason) {
              setState(() {
                _current = index;
              });
            },
          ),
          items: imgList.map((i) {
            return Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height,
              //color: Colors.red,
              child: Image.asset(
                "assets/images/macbook.jpg",
                fit: BoxFit.cover,
              ),
            );
          }).toList(),
        ),
      ],
    ));
  }

  Widget sellerinfo() {
    return Padding(
      padding: const EdgeInsets.all(15.0),
      child: Row(
        children: [
          ClipRRect(
              borderRadius: BorderRadius.circular(50),
              child: Container(
                width: 50,
                height: 50,
                child: Image.asset("assets/images/user.png"),
              )),
          SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "거래쿨",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              Text("신뢰도 보통"),
            ],
          ),
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                GestureDetector(
                  onTap: () => Navigator.of(context).pushNamed(
                    HistoryScreen.routename,
                  ),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      color: Theme.of(context).primaryColor,
                    ),
                    child: Row(
                      children: [
                        const Text(
                          "거래 기록",
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        Image(
                          image: AssetImage("assets/images/trade.png"),
                          width: 30,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget contentdetail() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SizedBox(height: 20),
          Text(
            "2019 맥북 프로 터치바",
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
          ),
          Text(
            "디지털기기 . 2시간 전",
            style: TextStyle(color: Colors.grey, fontSize: 12),
          ),
          SizedBox(height: 15),
          Text(
            "맥북 프로 터치바 판매합니다.\n\n새로 나왔을 때부터 애지중지 케이스 끼워가며 사용했어요. \n떨어뜨린 적 거의 없고, \n배터리 사이클도 300으로 괜찮습니다.\n\n모든 기능 잘 작동합니다.\n영등포역 1번 출구에서 직거래가능합니다.",
            style: TextStyle(
              fontSize: 15,
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget line() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 15),
      height: 1,
      color: Colors.grey.withOpacity(0.3),
    );
  }

  Widget _bodyWidget() {
    return SingleChildScrollView(
      child: Column(
        children: [
          sliderWidget(),
          sellerinfo(),
          line(),
          contentdetail(),
        ],
      ),
    );
  }

  Widget _bottomBarWidget() {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Container(
        padding: const EdgeInsets.only(top: 3),
        decoration: BoxDecoration(
          border: Border(
            top: BorderSide(
              width: 1,
              color: Colors.grey,
            ),
          ),
        ),
        width: MediaQuery.of(context).size.width,
        height: 55,
        //color : Colors.transparent,
        child: Row(
          children: [
            GestureDetector(
              onTap: () {
                setState(() {
                  putincart = !putincart;
                });
                scaffoldKey.currentState!.showSnackBar(
                  SnackBar(
                    duration: Duration(milliseconds: 1000),
                    content:
                        Text(putincart ? "관심목록에 추가되었습니다." : "관심목록에서 제거되었습니다."),
                  ),
                );
              },
              child: Image.asset(
                putincart
                    ? 'assets/images/cart-fill.png'
                    : 'assets/images/cart-empty.png',
                width: 25,
                height: 25,
                color: Color(0xff5296D5),
              ),
            ),
            Container(
              margin: const EdgeInsets.only(left: 15, right: 10),
              width: 1.5,
              height: 40,
              color: Colors.grey.withOpacity(0.3),
            ),
            Column(
              children: [
                SizedBox(
                  height: 8.0,
                ),
                Text(
                  "800,000원",
                  style: TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                  ),
                )
              ],
            ),
            Expanded(
                child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: Color(0xff5296D5),
                  ),
                  child: Text(
                    "채팅하기",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ))
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      extendBodyBehindAppBar: true,
      appBar: _appbarWidget(),
      body: _bodyWidget(),
      bottomNavigationBar: _bottomBarWidget(),
    );
  }
}
